// components/siderBlock/index.js
const app = getApp()

var coord = 0
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        param: {
            type: Object,
            value: {}
        },
    },

    /**
     * 组件的初始数据
     */
    data: {
        isIos: true,
        areaWidth: 0,
        x: 0,
        deviation: 2.5,
        // 滑块目标点偏移量
        deviationVal: 10,
        bgWidth: 30,
        tempX: 0,
        isStart: true,
        boxImg: './images/start.gif',
        endImg: './images/end.png',
        successImg: '',
        canShow: true,
        pathQuery: 'http://dev.du.hupu.com/mapi/activity/bargainCaptcha?token=' + app.globalData.loginToken
    },

    /**
     * 组件的方法列表
     */
    methods: {
        // 拖动滑块事件触发的方法
        drag(e) {
            coord = e.detail.x
            
            this.setData({
                tempX: e.detail.x
            })
        },
        dragOver(e) {
            var that = this
            // var maxNumLeft = that.properties.val - that.data.deviationVal
            // var maxNumRight = that.properties.val + that.data.deviationVal

            let overVal = Math.floor(coord / that.data.areaWidth * 100 + 1)
            let params = {
                bargainId: that.properties.param.bargainId,
                captcha: overVal
            }
            if (that.properties.param.encryptedData != null) {
                params.encryptedData = that.properties.param.encryptedData
                params.iv = that.properties.param.iv
            }


            console.log('params: ', params)
            app.duserver.postRequest("activity/bargain", params)
                .then(res => {
                    if (res.status == 200) {
                        this.setData({
                            canShow: false,
                            isStart: false,
                        })
                        let opt = {
                            siderSuccess: true,
                            data: res.data
                        }
                        this.triggerEvent('siderOver', opt)
                    } else {
                        that.setData({
                            x: 0,
                            isStart: true,
                            canShow: true,
                        })

                        let opt = {
                            siderSuccess: false,
                            msg: res.msg

                        }
                        this.triggerEvent('siderOver', opt)
                    }
                })

            // if (coord >= maxNumLeft && coord <= maxNumRight) {
            //     that.setData({
            //         x: that.properties.val,
            //         isStart: false,
            //         canShow: false,
            //     })
            //     wx.showToast({
            //         title: 'success',
            //         icon: 'success',
            //         duration: 2000,
            //     })
            //     let opt = {
            //         siderSuccess: true
            //     }
            //     that.triggerEvent('siderOver', opt)
            // } else {
            //     that.setData({
            //         x: 0,
            //         isStart: true,
            //         canShow: true,
            //     })
            // }
        },
    },
    ready: function() {
        var that = this
        wx.getSystemInfo({
            success: function (res) {
                // var finVal = Math.floor(res.windowWidth * that.properties.val / 100) - 110
                var d = Math.floor(res.windowWidth * that.data.deviation / 100)
                console.log('model: ', res.model) 
                let isIos =  true
                if (res.model.indexOf('iPhone 5') >= 0) {
                    isIos = false
                } else if(res.model.indexOf('iPhone 6') >= 0) {
                    isIos = false
                } else if (res.model.indexOf('iPhone SE') >= 0) {
                    isIos = false
                } else if (res.model.indexOf('iPhone') < 0){
                    isIos = false
                }
                console.log('isIos: ', isIos)                
                that.setData({
                    deviationVal: d,
                    areaWidth: res.windowWidth * 0.9,
                    isIos: isIos
                })
            },
        })
    },
})